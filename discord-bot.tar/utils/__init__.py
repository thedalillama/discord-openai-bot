"""
Utility functions package for the Discord bot.
"""
